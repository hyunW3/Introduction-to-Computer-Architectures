#define SPIM_VERSION "Version 9.1.18 of November 23, 2016"
